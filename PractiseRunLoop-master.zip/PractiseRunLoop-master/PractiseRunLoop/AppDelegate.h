//
//  AppDelegate.h
//  PractiseRunLoop
//
//  Created by robot on 4/24/16.
//  Copyright © 2016 codeFighter.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

